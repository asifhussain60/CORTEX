# CORTEX v3.2.0 Upgrade Guide

**Quick Reference for Upgrading to TDD Mastery**

---

## 🚀 Quick Start (5 Minutes)

### 1. Install (New Users)
```bash
cd cortex-user-v3.2.0
pip install -r requirements.txt
```

### 2. Upgrade (Existing Users)
```bash
# Backup current installation
cp -r /path/to/cortex /path/to/cortex-backup

# Replace with v3.2.0
# Merge cortex.config.json settings if customized
```

### 3. Verify Installation
```bash
python3 scripts/validate_tdd_mastery_deployment.py
```

**Expected Output:**
```
✅ ALL CHECKS PASSED - TDD MASTERY READY FOR DEPLOYMENT
```

---

## 🎯 What's New

### TDD Mastery System
- **ViewDiscoveryAgent** - Discover test cases from code
- **DebugAgent** - Auto-fix failing tests (RED→GREEN)
- **FeedbackAgent** - Suggest green refactoring
- **RefactoringEngine** - Detect code smells + AI refactoring
- **TDD State Machine** - RED→GREEN→REFACTOR orchestration

---

## 📖 Essential Documentation

### Must Read (5 min)
1. **TDD-MASTERY-QUICKSTART.md** - Feature overview + examples
   - Location: `cortex-brain/documents/implementation-guides/`

### Deep Dive (30 min)
2. **TDD-MASTERY-INTEGRATION-PLAN.md** - Complete implementation details
3. **test-strategy.yaml** - Comprehensive testing strategy

### Reference
4. **CORTEX.prompt.md** - Natural language commands
   - Location: `.github/prompts/`

---

## 🔧 Configuration

### Default Config (No Changes Needed)
The package includes optimized defaults in `cortex.config.json`.

### Optional Tuning
```json
{
  "tdd": {
    "max_debug_retries": 3,
    "refactoring_threshold": 0.7,
    "test_timeout": 30
  }
}
```

---

## ✅ Validation

### Quick Check
```bash
python3 scripts/validate_tdd_mastery_deployment.py
```

### Detailed Check
```bash
# Verify all components
ls -lh src/workflows/tdd_*.py
ls -lh src/agents/*discovery*.py
ls -lh cortex-brain/agents/debug*.py
ls -lh tests/test_tdd_*.py
```

---

## 🐛 Troubleshooting

### Issue: Validation Script Not Found
**Solution:**
```bash
# Make sure you're in the package root
cd cortex-user-v3.2.0
python3 scripts/validate_tdd_mastery_deployment.py
```

### Issue: Missing Dependencies
**Solution:**
```bash
pip install -r requirements.txt --upgrade
```

### Issue: Import Errors
**Solution:**
```bash
# Ensure PYTHONPATH includes CORTEX root
export PYTHONPATH="${PYTHONPATH}:/path/to/cortex-user-v3.2.0"
```

---

## 📊 Package Contents

### Files: 1,055
### Size: 15.65 MB
### Key Components: 19 TDD Mastery files

**Documentation:** 6 files (110 KB)  
**Workflows:** 3 files (75 KB)  
**Agents:** 4 files (50 KB)  
**Tests:** 1 file (28 tests, 22 KB)  

---

## 🎯 Next Steps

1. ✅ **Verify Installation** - Run validation script
2. 📖 **Read Quickstart** - 5 minutes to understand TDD Mastery
3. 🧪 **Try Example** - Use natural language commands in CORTEX.prompt.md
4. 🔧 **Customize** - Adjust settings in cortex.config.json (optional)

---

## 🔗 Quick Links

- **Quickstart:** `cortex-brain/documents/implementation-guides/TDD-MASTERY-QUICKSTART.md`
- **Commands:** `.github/prompts/CORTEX.prompt.md`
- **Capabilities:** `cortex-brain/capabilities.yaml` (search "tdd_mastery")
- **Tests:** `tests/test_tdd_phase4_integration.py` (28 tests)

---

## ℹ️ Support

**Version:** 3.2.0  
**Build Date:** November 24, 2024  
**Status:** Production Ready  

**Author:** Asif Hussain  
**License:** Source-Available (Use Allowed, No Contributions)

---

**Ready to use TDD Mastery? Start with the Quickstart Guide! 🚀**
