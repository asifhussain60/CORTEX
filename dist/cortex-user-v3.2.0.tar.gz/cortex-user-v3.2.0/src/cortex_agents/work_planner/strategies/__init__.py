"""Task generation strategies."""

from .task_generator import TaskGenerator

__all__ = ["TaskGenerator"]
