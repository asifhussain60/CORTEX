"""Tag management modules for Knowledge Graph."""

from .tag_manager import TagManager

__all__ = ['TagManager']
