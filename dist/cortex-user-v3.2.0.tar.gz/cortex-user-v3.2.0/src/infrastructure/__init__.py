"""
Infrastructure Layer
Handles external concerns: database, file system, external APIs, etc.
"""
