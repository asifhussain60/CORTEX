"""
Track A Integrations Package

Contains integration adapters for Track A conversation pipeline.

Author: Asif Hussain
Copyright: © 2024-2025 Asif Hussain. All rights reserved.
"""

__version__ = "0.1.0"
