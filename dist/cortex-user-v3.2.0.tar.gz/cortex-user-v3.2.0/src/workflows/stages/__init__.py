"""
CORTEX Workflow Stages

Example stage implementations for testing and demonstration.
"""

__all__ = ["DoDDoRClarifier", "CodeCleanup", "DocGenerator"]
