"""CORTEX Tier 0: Instinct Layer - Immutable Governance"""
