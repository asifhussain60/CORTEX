"""FIFO queue management module."""
from .queue_manager import QueueManager

__all__ = ['QueueManager']
