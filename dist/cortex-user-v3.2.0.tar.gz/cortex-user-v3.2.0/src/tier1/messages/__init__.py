"""Message storage module."""
from .message_store import MessageStore

__all__ = ['MessageStore']
