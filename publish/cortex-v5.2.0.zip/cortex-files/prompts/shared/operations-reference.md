# CORTEX Operations Reference

**Available Operations:**

| Operation | Natural Language Examples | Status | What It Does |
|-----------|--------------------------|--------|--------------|
| **Demo** | "demo", "show capabilities", "tutorial" | ✅ READY | Interactive walkthrough of CORTEX |
| **Setup** | "setup", "configure", "initialize" | ✅ READY | Configure development environment |
| **Design Sync** | "sync design", "align design", "consolidate status" | ✅ READY | Synchronize design docs with implementation |
| **Story Refresh** | "refresh story", "update story" | 🟡 VALIDATION | Validate CORTEX story structure (validation-only, see limitations) |
| **Cleanup** | "cleanup", "clean workspace", "tidy up" | 🟡 PARTIAL | Clean temp files, optimize databases |
| **Documentation** | "update docs", "build docs" | ⏸️ PENDING | Generate/build documentation site |
| **Brain Protection** | "check brain", "validate protection" | ⏸️ PENDING | Validate brain integrity |
| **Run Tests** | "run tests", "test suite" | ⏸️ PENDING | Execute test suite with coverage |

**Legend:**
- ✅ READY - Fully implemented and tested with real logic
- 🟡 VALIDATION - Validation-only (no transformation yet)
- 🟡 PARTIAL - Core works, integration testing in progress
- ⏸️ PENDING - Architecture ready, modules pending
- 🎯 PLANNED - Design phase (CORTEX 2.1+)

**Try it now:**
```python
from src.operations import execute_operation

# All natural language - no slash commands needed!
report = execute_operation('setup')  # Works!
report = execute_operation('refresh story')  # Works!
report = execute_operation('cleanup', profile='standard')  # Works!
```
