# CORTEX 2.0 Conversation State Management

**Document:** 03-conversation-state.md  
**Version:** 2.0.0-alpha  
**Date:** 2025-11-07

---

## 🎯 Purpose

Enable seamless conversation resume after interruptions by:
- Tracking conversation state explicitly
- Preserving task progress and context
- Enabling "pick up where you left off" functionality
- Managing actionable requests across sessions

---

## ❌ Current Pain Points (CORTEX 1.0)

### Problem 1: No Conversation Resume
```
User: "Add purple button" → CORTEX plans 4-phase implementation
[User gets interrupted, closes chat]
[User returns 2 hours later]
User: "Continue"
CORTEX: "Continue what? I don't remember what we were doing."
```

### Problem 2: Lost Progress
```
Phase 1: ✅ Tests created (RED)
Phase 2: ✅ Implementation done (GREEN)
Phase 3: ⏸️ Interrupted during validation
[Session ends]
[New session starts]
Phase 3: ❌ Must re-validate from scratch (lost context)
```

### Problem 3: Ambiguous State
```
Conversation stored in Tier 1: ✅
But no record of:
  - Which phase was active?
  - What files were modified?
  - What was the next planned action?
  - Were tests passing or failing?
```

### Problem 4: Multi-Task Confusion
```
Task A: "Add export feature" (in progress)
Task B: "Fix login bug" (starts in parallel)
[Which task is active?]
[Which files belong to which task?]
[Can't track separately]
```

---

## ✅ CORTEX 2.0 Solution

### Architecture Overview

```
┌──────────────────────────────────────────────────────────┐
│            Conversation State Manager (NEW)               │
├──────────────────────────────────────────────────────────┤
│  • Tracks conversation lifecycle                         │
│  • Manages active/paused/completed states                │
│  • Preserves task progress                               │
│  • Generates resume prompts                              │
│  • Handles checkpoints                                   │
└────────────────┬─────────────────────────────────────────┘
                 │
    ┌────────────┴────────────┐
    │                         │
┌───▼────────────────┐  ┌────▼────────────────┐
│  Task Tracker (NEW) │  │ Checkpoint Manager  │
├────────────────────┤  ├─────────────────────┤
│ • Task states      │  │ • Save state        │
│ • Dependencies     │  │ • Load state        │
│ • Files touched    │  │ • Rollback support  │
│ • Phase tracking   │  │ • Incremental saves │
└────────────────────┘  └─────────────────────┘
         │                       │
         └───────────┬───────────┘
                     │
         ┌───────────▼──────────────┐
         │  Tier 1 Database (NEW)   │
         │  conversation_state.db   │
         ├──────────────────────────┤
         │  • conversations         │
         │  • tasks                 │
         │  • checkpoints           │
         │  • task_files            │
         └──────────────────────────┘
```

---

## 🗄️ Database Schema (conversation_state.db)

### Table: conversations

```sql
CREATE TABLE conversations (
    conversation_id TEXT PRIMARY KEY,
    user_request TEXT NOT NULL,
    intent TEXT NOT NULL,  -- PLAN, EXECUTE, TEST, VALIDATE, etc.
    status TEXT NOT NULL,  -- active, paused, completed, failed
    created_at TIMESTAMP NOT NULL,
    last_updated TIMESTAMP NOT NULL,
    completed_at TIMESTAMP,
    
    -- State tracking
    current_phase TEXT,    -- RED, GREEN, REFACTOR, or custom
    current_task_id TEXT,  -- Currently active task
    
    -- Resume support
    resume_prompt TEXT,    -- What to show on resume
    context_summary TEXT,  -- Brief summary of conversation
    
    -- Metadata
    agent_assigned TEXT,   -- Which agent is handling this
    hemisphere TEXT,       -- LEFT or RIGHT
    priority INTEGER DEFAULT 50,
    
    FOREIGN KEY (current_task_id) REFERENCES tasks(task_id)
);

CREATE INDEX idx_conversations_status ON conversations(status);
CREATE INDEX idx_conversations_updated ON conversations(last_updated);
CREATE INDEX idx_conversations_intent ON conversations(intent);
```

### Table: tasks

```sql
CREATE TABLE tasks (
    task_id TEXT PRIMARY KEY,
    conversation_id TEXT NOT NULL,
    description TEXT NOT NULL,
    status TEXT NOT NULL,  -- not_started, in_progress, completed, failed, blocked
    
    -- Phase tracking
    phase TEXT,            -- RED, GREEN, REFACTOR, PLAN, EXECUTE, etc.
    phase_order INTEGER,   -- 1, 2, 3, 4... for multi-phase tasks
    
    -- Dependencies
    depends_on TEXT,       -- JSON array of task_id dependencies
    blocks TEXT,           -- JSON array of task_ids this blocks
    
    -- Execution tracking
    next_action TEXT,      -- Explicit next step
    files_to_modify TEXT,  -- JSON array of file paths
    tests_to_run TEXT,     -- JSON array of test file paths
    
    -- Results
    result TEXT,           -- Success message or error details
    files_modified TEXT,   -- JSON array of actually modified files
    tests_passed BOOLEAN,  -- Test status
    
    -- Timestamps
    created_at TIMESTAMP NOT NULL,
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    
    FOREIGN KEY (conversation_id) REFERENCES conversations(conversation_id)
);

CREATE INDEX idx_tasks_conversation ON tasks(conversation_id);
CREATE INDEX idx_tasks_status ON tasks(status);
CREATE INDEX idx_tasks_phase ON tasks(phase);
CREATE INDEX idx_tasks_order ON tasks(conversation_id, phase_order);
```

### Table: checkpoints

```sql
CREATE TABLE checkpoints (
    checkpoint_id TEXT PRIMARY KEY,
    conversation_id TEXT NOT NULL,
    checkpoint_type TEXT NOT NULL,  -- manual, auto, phase_complete, error
    
    -- State snapshot
    state_snapshot TEXT NOT NULL,   -- JSON snapshot of full conversation state
    files_state TEXT,               -- JSON of file checksums at checkpoint
    
    -- Context
    description TEXT,
    created_at TIMESTAMP NOT NULL,
    created_by TEXT,                -- user, system, agent
    
    -- Rollback support
    can_rollback BOOLEAN DEFAULT TRUE,
    
    FOREIGN KEY (conversation_id) REFERENCES conversations(conversation_id)
);

CREATE INDEX idx_checkpoints_conversation ON checkpoints(conversation_id);
CREATE INDEX idx_checkpoints_created ON checkpoints(created_at);
CREATE INDEX idx_checkpoints_type ON checkpoints(checkpoint_type);
```

### Table: task_files

```sql
CREATE TABLE task_files (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id TEXT NOT NULL,
    file_path TEXT NOT NULL,
    operation TEXT NOT NULL,  -- create, modify, delete, read
    
    -- State tracking
    before_checksum TEXT,     -- File hash before modification
    after_checksum TEXT,      -- File hash after modification
    
    -- Details
    lines_added INTEGER DEFAULT 0,
    lines_removed INTEGER DEFAULT 0,
    status TEXT,              -- pending, in_progress, completed, failed
    
    -- Timestamps
    recorded_at TIMESTAMP NOT NULL,
    
    FOREIGN KEY (task_id) REFERENCES tasks(task_id),
    UNIQUE(task_id, file_path, operation)
);

CREATE INDEX idx_task_files_task ON task_files(task_id);
CREATE INDEX idx_task_files_path ON task_files(file_path);
CREATE INDEX idx_task_files_operation ON task_files(operation);
```

---

## 🏗️ Implementation: State Manager

```python
# src/conversation/state_manager.py

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any
from datetime import datetime
from enum import Enum
import json
import uuid

class ConversationStatus(Enum):
    """Conversation lifecycle states"""
    ACTIVE = "active"           # Currently being processed
    PAUSED = "paused"           # Interrupted, can resume
    COMPLETED = "completed"     # Successfully finished
    FAILED = "failed"           # Ended with error
    CANCELLED = "cancelled"     # User cancelled

class TaskStatus(Enum):
    """Task lifecycle states"""
    NOT_STARTED = "not_started"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    BLOCKED = "blocked"         # Waiting on dependencies

class Phase(Enum):
    """TDD phases and general workflow phases"""
    # TDD cycle
    RED = "RED"                 # Tests failing (expected)
    GREEN = "GREEN"             # Tests passing
    REFACTOR = "REFACTOR"       # Cleanup/optimization
    
    # Planning phases
    PLAN = "PLAN"               # Creating work plan
    ANALYZE = "ANALYZE"         # Understanding requirements
    
    # Execution phases  
    EXECUTE = "EXECUTE"         # Implementing code
    TEST = "TEST"               # Running tests
    VALIDATE = "VALIDATE"       # Health checks
    COMMIT = "COMMIT"           # Committing changes

@dataclass
class Task:
    """Represents a single actionable task"""
    task_id: str
    conversation_id: str
    description: str
    status: TaskStatus
    phase: Optional[Phase] = None
    phase_order: int = 0
    
    # Dependencies
    depends_on: List[str] = field(default_factory=list)
    blocks: List[str] = field(default_factory=list)
    
    # Execution details
    next_action: str = ""
    files_to_modify: List[str] = field(default_factory=list)
    tests_to_run: List[str] = field(default_factory=list)
    
    # Results
    result: str = ""
    files_modified: List[str] = field(default_factory=list)
    tests_passed: Optional[bool] = None
    
    # Timestamps
    created_at: datetime = field(default_factory=datetime.now)
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for storage"""
        return {
            "task_id": self.task_id,
            "conversation_id": self.conversation_id,
            "description": self.description,
            "status": self.status.value,
            "phase": self.phase.value if self.phase else None,
            "phase_order": self.phase_order,
            "depends_on": json.dumps(self.depends_on),
            "blocks": json.dumps(self.blocks),
            "next_action": self.next_action,
            "files_to_modify": json.dumps(self.files_to_modify),
            "tests_to_run": json.dumps(self.tests_to_run),
            "result": self.result,
            "files_modified": json.dumps(self.files_modified),
            "tests_passed": self.tests_passed,
            "created_at": self.created_at.isoformat(),
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Task':
        """Create from dictionary (from database)"""
        return cls(
            task_id=data["task_id"],
            conversation_id=data["conversation_id"],
            description=data["description"],
            status=TaskStatus(data["status"]),
            phase=Phase(data["phase"]) if data["phase"] else None,
            phase_order=data["phase_order"],
            depends_on=json.loads(data["depends_on"]) if data["depends_on"] else [],
            blocks=json.loads(data["blocks"]) if data["blocks"] else [],
            next_action=data.get("next_action", ""),
            files_to_modify=json.loads(data["files_to_modify"]) if data["files_to_modify"] else [],
            tests_to_run=json.loads(data["tests_to_run"]) if data["tests_to_run"] else [],
            result=data.get("result", ""),
            files_modified=json.loads(data["files_modified"]) if data["files_modified"] else [],
            tests_passed=data.get("tests_passed"),
            created_at=datetime.fromisoformat(data["created_at"]),
            started_at=datetime.fromisoformat(data["started_at"]) if data["started_at"] else None,
            completed_at=datetime.fromisoformat(data["completed_at"]) if data["completed_at"] else None,
        )

@dataclass
class ConversationState:
    """Complete conversation state"""
    conversation_id: str
    user_request: str
    intent: str
    status: ConversationStatus
    
    created_at: datetime
    last_updated: datetime
    completed_at: Optional[datetime] = None
    
    # State tracking
    current_phase: Optional[Phase] = None
    current_task_id: Optional[str] = None
    
    # Resume support
    resume_prompt: str = ""
    context_summary: str = ""
    
    # Metadata
    agent_assigned: str = ""
    hemisphere: str = ""  # LEFT or RIGHT
    priority: int = 50
    
    # Tasks (not stored in this object, fetched separately)
    tasks: List[Task] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for storage"""
        return {
            "conversation_id": self.conversation_id,
            "user_request": self.user_request,
            "intent": self.intent,
            "status": self.status.value,
            "created_at": self.created_at.isoformat(),
            "last_updated": self.last_updated.isoformat(),
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "current_phase": self.current_phase.value if self.current_phase else None,
            "current_task_id": self.current_task_id,
            "resume_prompt": self.resume_prompt,
            "context_summary": self.context_summary,
            "agent_assigned": self.agent_assigned,
            "hemisphere": self.hemisphere,
            "priority": self.priority,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ConversationState':
        """Create from dictionary (from database)"""
        return cls(
            conversation_id=data["conversation_id"],
            user_request=data["user_request"],
            intent=data["intent"],
            status=ConversationStatus(data["status"]),
            created_at=datetime.fromisoformat(data["created_at"]),
            last_updated=datetime.fromisoformat(data["last_updated"]),
            completed_at=datetime.fromisoformat(data["completed_at"]) if data["completed_at"] else None,
            current_phase=Phase(data["current_phase"]) if data["current_phase"] else None,
            current_task_id=data.get("current_task_id"),
            resume_prompt=data.get("resume_prompt", ""),
            context_summary=data.get("context_summary", ""),
            agent_assigned=data.get("agent_assigned", ""),
            hemisphere=data.get("hemisphere", ""),
            priority=data.get("priority", 50),
        )

class ConversationStateManager:
    """Manages conversation state lifecycle"""
    
    def __init__(self, db_path: str):
        """Initialize with database path"""
        self.db_path = db_path
        # Database connection management (implementation omitted)
    
    def create_conversation(self, 
                          user_request: str, 
                          intent: str,
                          agent: str = "",
                          hemisphere: str = "") -> ConversationState:
        """
        Create a new conversation
        
        Args:
            user_request: Original user request
            intent: Detected intent (PLAN, EXECUTE, etc.)
            agent: Assigned agent name
            hemisphere: LEFT or RIGHT
        
        Returns:
            ConversationState object
        """
        conv_id = f"conv-{uuid.uuid4().hex[:8]}"
        now = datetime.now()
        
        state = ConversationState(
            conversation_id=conv_id,
            user_request=user_request,
            intent=intent,
            status=ConversationStatus.ACTIVE,
            created_at=now,
            last_updated=now,
            agent_assigned=agent,
            hemisphere=hemisphere,
            context_summary=self._generate_summary(user_request)
        )
        
        # Store in database
        self._save_conversation(state)
        
        return state
    
    def add_task(self, 
                conversation_id: str,
                description: str,
                phase: Optional[Phase] = None,
                phase_order: int = 0,
                depends_on: Optional[List[str]] = None) -> Task:
        """
        Add a task to a conversation
        
        Args:
            conversation_id: Parent conversation ID
            description: Task description
            phase: Workflow phase
            phase_order: Order in multi-phase plan
            depends_on: List of task IDs this depends on
        
        Returns:
            Task object
        """
        task_id = f"task-{uuid.uuid4().hex[:8]}"
        
        task = Task(
            task_id=task_id,
            conversation_id=conversation_id,
            description=description,
            status=TaskStatus.NOT_STARTED,
            phase=phase,
            phase_order=phase_order,
            depends_on=depends_on or []
        )
        
        # Store in database
        self._save_task(task)
        
        # Update conversation
        self._update_conversation_timestamp(conversation_id)
        
        return task
    
    def start_task(self, task_id: str) -> Task:
        """Mark task as in-progress"""
        task = self._load_task(task_id)
        task.status = TaskStatus.IN_PROGRESS
        task.started_at = datetime.now()
        
        self._save_task(task)
        
        # Update conversation current task
        self._update_conversation_current_task(task.conversation_id, task_id)
        
        return task
    
    def complete_task(self, 
                     task_id: str,
                     result: str = "",
                     files_modified: Optional[List[str]] = None,
                     tests_passed: Optional[bool] = None) -> Task:
        """Mark task as completed"""
        task = self._load_task(task_id)
        task.status = TaskStatus.COMPLETED
        task.completed_at = datetime.now()
        task.result = result
        task.files_modified = files_modified or []
        task.tests_passed = tests_passed
        
        self._save_task(task)
        
        # Check if all tasks in conversation are complete
        self._check_conversation_completion(task.conversation_id)
        
        return task
    
    def fail_task(self, task_id: str, error: str) -> Task:
        """Mark task as failed"""
        task = self._load_task(task_id)
        task.status = TaskStatus.FAILED
        task.completed_at = datetime.now()
        task.result = f"FAILED: {error}"
        
        self._save_task(task)
        
        # Mark conversation as failed
        self._fail_conversation(task.conversation_id, error)
        
        return task
    
    def pause_conversation(self, conversation_id: str) -> ConversationState:
        """Pause a conversation (interrupted)"""
        state = self._load_conversation(conversation_id)
        state.status = ConversationStatus.PAUSED
        state.last_updated = datetime.now()
        
        # Generate resume prompt
        state.resume_prompt = self._generate_resume_prompt(state)
        
        self._save_conversation(state)
        
        # Create checkpoint
        self.create_checkpoint(
            conversation_id, 
            checkpoint_type="auto",
            description="Auto-checkpoint on pause"
        )
        
        return state
    
    def resume_conversation(self, conversation_id: str) -> ConversationState:
        """Resume a paused conversation"""
        state = self._load_conversation(conversation_id)
        
        if state.status != ConversationStatus.PAUSED:
            raise ValueError(f"Cannot resume conversation in status: {state.status}")
        
        state.status = ConversationStatus.ACTIVE
        state.last_updated = datetime.now()
        
        self._save_conversation(state)
        
        return state
    
    def create_checkpoint(self,
                         conversation_id: str,
                         checkpoint_type: str = "manual",
                         description: str = "") -> str:
        """
        Create a checkpoint for rollback
        
        Args:
            conversation_id: Conversation to checkpoint
            checkpoint_type: manual, auto, phase_complete, error
            description: Checkpoint description
        
        Returns:
            checkpoint_id
        """
        checkpoint_id = f"cp-{uuid.uuid4().hex[:8]}"
        
        # Load full state
        state = self._load_conversation(conversation_id)
        state.tasks = self._load_tasks(conversation_id)
        
        # Create state snapshot
        snapshot = {
            "conversation": state.to_dict(),
            "tasks": [task.to_dict() for task in state.tasks],
            "timestamp": datetime.now().isoformat()
        }
        
        # Store checkpoint
        with self._get_connection() as conn:
            conn.execute("""
                INSERT INTO checkpoints 
                (checkpoint_id, conversation_id, checkpoint_type, state_snapshot, 
                 description, created_at, created_by)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                checkpoint_id,
                conversation_id,
                checkpoint_type,
                json.dumps(snapshot),
                description,
                datetime.now(),
                "system"
            ))
        
        return checkpoint_id
    
    def get_resume_prompt(self, conversation_id: str) -> str:
        """Get resume prompt for a paused conversation"""
        state = self._load_conversation(conversation_id)
        
        if not state.resume_prompt:
            state.resume_prompt = self._generate_resume_prompt(state)
        
        return state.resume_prompt
    
    def _generate_resume_prompt(self, state: ConversationState) -> str:
        """Generate a helpful resume prompt"""
        tasks = self._load_tasks(state.conversation_id)
        
        completed = [t for t in tasks if t.status == TaskStatus.COMPLETED]
        in_progress = [t for t in tasks if t.status == TaskStatus.IN_PROGRESS]
        pending = [t for t in tasks if t.status == TaskStatus.NOT_STARTED]
        
        prompt = f"**Resume Conversation:** {state.context_summary}\n\n"
        prompt += f"**Original Request:** {state.user_request}\n\n"
        
        if completed:
            prompt += "**✅ Completed:**\n"
            for task in completed:
                prompt += f"  - {task.description}\n"
            prompt += "\n"
        
        if in_progress:
            task = in_progress[0]
            prompt += f"**⏸️ Interrupted During:** {task.description}\n"
            if task.next_action:
                prompt += f"**Next Action:** {task.next_action}\n"
            prompt += "\n"
        
        if pending:
            prompt += "**📋 Remaining:**\n"
            for task in pending[:3]:  # Show first 3
                prompt += f"  - {task.description}\n"
            if len(pending) > 3:
                prompt += f"  - ...and {len(pending) - 3} more\n"
            prompt += "\n"
        
        prompt += "**To Continue:** Say 'continue' or 'resume'"
        
        return prompt
    
    def _generate_summary(self, user_request: str) -> str:
        """Generate brief summary of conversation"""
        # Simple summarization (could be enhanced with AI)
        if len(user_request) <= 60:
            return user_request
        return user_request[:57] + "..."
    
    # Database helper methods (implementation omitted for brevity)
    def _save_conversation(self, state: ConversationState): pass
    def _load_conversation(self, conversation_id: str) -> ConversationState: pass
    def _save_task(self, task: Task): pass
    def _load_task(self, task_id: str) -> Task: pass
    def _load_tasks(self, conversation_id: str) -> List[Task]: pass
    def _update_conversation_timestamp(self, conversation_id: str): pass
    def _update_conversation_current_task(self, conversation_id: str, task_id: str): pass
    def _check_conversation_completion(self, conversation_id: str): pass
    def _fail_conversation(self, conversation_id: str, error: str): pass
    def _get_connection(self): pass
```

---

## 🔄 Integration with CORTEX Agents

### Entry Point Integration

```python
# src/entry_point/cortex_entry.py (Enhanced)

from conversation.state_manager import ConversationStateManager, Phase

class CortexEntry:
    def __init__(self):
        self.state_manager = ConversationStateManager(
            db_path=config.conversation_state_db
        )
    
    def process(self, user_request: str) -> str:
        """Process user request with state tracking"""
        
        # Check for resume request
        if user_request.lower() in ["continue", "resume", "pick up"]:
            return self._handle_resume()
        
        # Detect intent
        intent = self.intent_router.detect_intent(user_request)
        agent = self.intent_router.select_agent(intent)
        
        # Create conversation
        conversation = self.state_manager.create_conversation(
            user_request=user_request,
            intent=intent,
            agent=agent.name,
            hemisphere=agent.hemisphere
        )
        
        # Execute with state tracking
        try:
            result = agent.execute_with_state(conversation)
            return result
        except InterruptedError:
            # User interrupted - pause conversation
            self.state_manager.pause_conversation(conversation.conversation_id)
            resume_prompt = self.state_manager.get_resume_prompt(conversation.conversation_id)
            return f"Paused. {resume_prompt}"
    
    def _handle_resume(self) -> str:
        """Handle conversation resume"""
        # Find most recent paused conversation
        paused = self._find_paused_conversation()
        
        if not paused:
            return "No paused conversation found. What would you like to do?"
        
        # Show resume prompt
        resume_prompt = self.state_manager.get_resume_prompt(paused.conversation_id)
        
        # Resume conversation
        self.state_manager.resume_conversation(paused.conversation_id)
        
        # Continue execution
        agent = self._get_agent(paused.agent_assigned)
        result = agent.resume_execution(paused)
        
        return result
```

### Agent Integration (Work Planner Example)

```python
# src/cortex_agents/work_planner.py (Enhanced)

class WorkPlanner:
    def execute_with_state(self, conversation: ConversationState) -> str:
        """Execute planning with state tracking"""
        
        # Create plan
        plan = self._create_plan(conversation.user_request)
        
        # Create tasks from plan
        for i, phase in enumerate(plan.phases):
            task = self.state_manager.add_task(
                conversation_id=conversation.conversation_id,
                description=phase.description,
                phase=Phase[phase.name],
                phase_order=i + 1,
                depends_on=[plan.phases[i-1].task_id] if i > 0 else []
            )
            
            # Store task ID in phase
            phase.task_id = task.task_id
        
        # Create checkpoint after planning
        self.state_manager.create_checkpoint(
            conversation.conversation_id,
            checkpoint_type="phase_complete",
            description="Planning phase complete"
        )
        
        # Generate plan summary
        return self._format_plan(plan)
    
    def resume_execution(self, conversation: ConversationState) -> str:
        """Resume interrupted planning"""
        tasks = self.state_manager._load_tasks(conversation.conversation_id)
        
        # Find last incomplete task
        for task in tasks:
            if task.status != TaskStatus.COMPLETED:
                return f"Resuming: {task.description}\n\n{task.next_action}"
        
        return "All planning tasks complete!"
```

---

## ✅ Benefits

### 1. Seamless Resume
```
User: "Add purple button"
CORTEX: Creates 4-phase plan
[Interrupt after phase 2]

User: "Continue"
CORTEX: "Resuming: Phase 3 (Validation)
  ✅ Phase 1: Tests created (RED)
  ✅ Phase 2: Implementation done (GREEN)
  ⏸️ Phase 3: Running validation checks..."
```

### 2. Explicit Progress Tracking
```
Every task has:
  - Clear description
  - Current status
  - Next action
  - Files involved
  - Test status
```

### 3. Multi-Task Management
```
Task A: "Export feature" (Phase 3/4)
Task B: "Fix login bug" (Phase 2/2)

Clear separation:
  - Each task tracks its own files
  - Dependencies explicit
  - No confusion about which task is active
```

### 4. Rollback Support
```
Checkpoints created at:
  - End of each phase
  - Before risky operations
  - Manual user request

Rollback to any checkpoint if needed
```

---

**Next:** 04-path-management.md (Environment-agnostic path resolution)
